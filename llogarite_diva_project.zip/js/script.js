
$(document).ready(function () {
    const table = $('#divaTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'DIVA Deklarimi'
            },
            {
                extend: 'csvHtml5',
                title: 'DIVA Deklarimi'
            },
            {
                extend: 'pdfHtml5',
                title: 'DIVA Deklarimi',
                orientation: 'landscape',
                pageSize: 'A4'
            },
            {
                extend: 'print',
                title: 'DIVA Deklarimi'
            }
        ]
    });

    function calculateTAP(grossSalary) {
        if (grossSalary <= 50000) {
            return 0;
        } else if (grossSalary <= 60000) {
            return (grossSalary - 35000) * 0.13;
        } else if (grossSalary <= 200000) {
            return (grossSalary - 30000) * 0.13;
        } else {
            return 22100 + (grossSalary - 200000) * 0.23;
        }
    }

    function updateTotals() {
        let totalGrossSalary = 0;
        let totalTapCalculated = 0;

        $('#divaTable tbody tr').each(function () {
            const row = $(this);
            const bruto = parseFloat(row.find('td:eq(1)').text()) || 0;
            const tapCalculated = calculateTAP(bruto);

            totalGrossSalary += bruto;
            totalTapCalculated += tapCalculated;

            row.find('td:eq(2)').text(tapCalculated.toFixed(2));
        });

        const tapByLaw = calculateTAP(totalGrossSalary);

        $('#totalGrossSalary').text(totalGrossSalary.toFixed(2));
        $('#totalTapCalculated').text(totalTapCalculated.toFixed(2));
        $('#totalGrossSalaryTAP').text(totalGrossSalary.toFixed(2));
        $('#tapPayableByLaw').text(tapByLaw.toFixed(2));
        $('#tapPaidSoFar').text(totalTapCalculated.toFixed(2));
        $('#tapDifference').text((tapByLaw - totalTapCalculated).toFixed(2));
    }

    $('#divaTable tbody').on('input', 'td[contenteditable="true"]', function () {
        updateTotals();
    });

    $('#addRow').on('click', function () {
        const newRow = `<tr>
            <td contenteditable="true">Puna e Re</td>
            <td contenteditable="true">0</td>
            <td contenteditable="true">0</td>
        </tr>`;
        $('#divaTable tbody').append(newRow);
        updateTotals();
    });

    $('#removeRow').on('click', function () {
        if ($('#divaTable tbody tr').length > 0) {
            $('#divaTable tbody tr:last').remove();
            updateTotals();
        }
    });

    updateTotals();
});
